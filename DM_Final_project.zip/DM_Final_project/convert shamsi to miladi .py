# convert shamsi to miladi 
from asyncore import write
import jdatetime
import csv 
csv_list=[]
csv_birthdate_list=[]
csv_userid_list=[] # یوزر ایدی رو نگاه کردم توی مدلر میسینگ نداشت 
with open ("./dm_project_BenefactorsData.csv" , 'r') as file : 
    csvreader = csv.reader(file)
    for row in csvreader : 
        
        for i in range(0,len(row)):
            
            csv_list.append(row[i])
            



for i in range(3,len(csv_list),5):
    csv_birthdate_list.append(csv_list[i])

for i in range(5,len(csv_list),5):
    csv_userid_list.append(csv_list[i])

sal=[]
mah=[]
roz=[]

for i in range(1,len(csv_birthdate_list)):
    tarikh=""
    tarikh=csv_birthdate_list[i]
    m=""
    r=""
    s=""
    if(tarikh == ""):
        s=1500  # تاریخ شمسی 1500 جایگزین میسینگ ها شده که باید در مدلر دوباره به میسینگ تبدیل بشه 
        m=11
        r=11
        sal.append(s)
        mah.append(m)
        roz.append(r)
    else:
        #sal
        s=tarikh[0:4]
        s=int(s)
        sal.append(s)
            
        #mah
        m=tarikh[5:7]
        if m[0] == "0":
            m=m[1]
        m=int(m)
        mah.append(m)

        #roz
        r=tarikh[8:10]
        if r[0] == "0":
            r=r[1]
        r=int(r)
        roz.append(r)

listoflist_birthdate_rows=[]

list_new=[]
for i in range(0,len(csv_birthdate_list)-1):
    l_new=[]
    dictt={}

    l_new.append(csv_userid_list)
    listofrows=[]
    miladi=""
    miladi= jdatetime.date(day=roz[i] , month=mah[i] , year=sal[i]).togregorian()
    listofrows.append(str(miladi))
    #listoflist_birthdate_rows.append(csv_userid_list)
    #list_new=[[csv_userid_list[i]],listofrows]
    dictt={"UserID":csv_userid_list[i],"BirthDate_miladi_":str(miladi)}
    #listoflist_birthdate_rows.append(csv_userid_list[i],listofrows)
    listoflist_birthdate_rows.append(dictt)

header_dict=["UserID","BirthDate_miladi_"]
with open ("miladi.csv","w") as f:
    writer=csv.DictWriter(f,fieldnames=header_dict)
    writer.writeheader()
    for data in listoflist_birthdate_rows:
        writer.writerow(data)
